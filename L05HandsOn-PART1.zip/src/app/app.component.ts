import { Component } from '@angular/core';

import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent {
  public appPages = [
    {
      title: '',
      url: '/home',
      icon: 'md-arrow-round-back'
     
    },
    {
      title: 'Intro to Responsive Design',
      url: '/introduction',
      icon: 'cog'
    },
    {
      title: 'Core of Responsive Design',
      url: '/responsive',
      icon: 'cube'
    },
    {
      title: 'Design Prototype',
      url: '/design',
      icon: 'paper'
    },
    {
      title: 'Image Optimizer',
      url: '/image',
      icon: 'document'
    },
    {
      title: 'Result of Optimization',
      url: '/result',
      icon: 'flower'
    }
  ];

  

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }
}
