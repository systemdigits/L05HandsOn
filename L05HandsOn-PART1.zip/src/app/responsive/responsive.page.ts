import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-responsive',
  templateUrl: './responsive.page.html',
  styleUrls: ['./responsive.page.scss'],
})
export class ResponsivePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
